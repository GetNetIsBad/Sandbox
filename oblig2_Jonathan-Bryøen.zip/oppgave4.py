boker = ["Lord of the Rings: The Fellowship of the Ring,","Lord of the Rings: The Two Towers","Lord of the Rings: The Return of the King,"]

teller = 0

for i in range(len(boker)):
    print(boker[i])
    i += 1

while teller < 3:
    print(boker[teller])
    teller += 1