filmer = ["The Hobbit,","Farmer Giles of Ham,","The Fellowship of the Ring,","The Two Towers,","The Return of the King,","The Adventures of Tom Bombadil,","Tree and Leaf,"]

#printer to første og to siste ved bruk av plaseringen i listen
print(filmer[0],filmer[1],filmer[5],filmer[6])

filmer.append("The Simarillions,")
filmer.append("Unfinished Tales")

filmer[2:3] = ["Lord of the Rings: The Fellowship of the Ring,","Lord of the Rings: The Two Towers"]
filmer[4] = ["Lord of the Rings: The Return of the King,"]
filmer.sort
print (filmer)
