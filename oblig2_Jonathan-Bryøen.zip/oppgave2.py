tall = 9

# for løkke for oppgave 2

for i in range(93):
    if tall % 2 == 0:
        tall = tall + 1
    else:
        print(tall)
        tall = tall + 1

# while løkke for oppgave 2

while tall < 102:
    if tall % 2 == 0:
        tall = tall + 1
    else:
        print(tall)
        tall = tall + 1
